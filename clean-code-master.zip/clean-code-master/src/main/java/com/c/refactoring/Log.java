package com.c.refactoring;

import java.math.BigDecimal;

public class Log {

    public static void debug(String string, Object... val) {
        // TODO Auto-generated method stub

    }

    public static void logApplicationDebug(String string,
            Class<? extends Object> class1) {
        // TODO Auto-generated method stub

    }

    public static void logApplicationInfo(String string,
            BigDecimal allowanceDiff, Class<? extends Object> class1) {

    }

}
