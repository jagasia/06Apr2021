package com.c.refactoring.allowance;

public class File {

    String prevFileVersionStatus;

    public String getPrevFileVersionStatus() {
        return prevFileVersionStatus;
    }

    public void setPrevFileVersionStatus(String prevFileVersionStatus) {
        this.prevFileVersionStatus = prevFileVersionStatus;
    }

}
